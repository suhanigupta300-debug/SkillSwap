@echo off
cd /d "%~dp0"
node -v
echo Starting SkillSwap... open http://localhost:3000 in your browser
start "" http://localhost:3000
node server.js
pause

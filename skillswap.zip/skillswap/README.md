# SkillSwap

## Start (2 steps)
1. Install Node.js 22.13 or newer from https://nodejs.org (the LTS/Current download). Check with `node -v`.
2. Start the server:
   - Windows: double-click `start.bat`
   - Mac/Linux: double-click `start.command` (or run `node server.js`)

Your browser opens http://localhost:3000. **Keep the black terminal window open** while using the site.
Do NOT open `public/index.html` directly — always use the address above.

Data is stored in `data/skillswap.db` (created automatically). Delete the `data` folder to reset everything.

## Use it with other people
- Same Wi-Fi: they open `http://<your-computer-IP>:3000` (chat, skills and requests work).
- Voice/video calls need HTTPS (browser rule), so put the site online, e.g. deploy this folder to Render or Railway
  (start command: `node server.js`). Note: free hosts may wipe the database on restart unless you attach a disk.
